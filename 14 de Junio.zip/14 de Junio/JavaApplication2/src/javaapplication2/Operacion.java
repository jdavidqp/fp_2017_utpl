/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Administrador
 */
public class Operacion {
    
    public void suma(int valor1, int valor2){
        int suma;
        suma = valor1 + valor2;
        System.out.printf("La suma de %d mas %d \nEs igual a:\n\t%d\n",valor1, valor2, suma);
        
    }
    
    public void resta(int valor1, int valor2){
        int resta;
        resta = valor1 - valor2;
        System.out.printf("La resta de %d menos %d \nEs igual a:\n\t%d\n",valor1, valor2, resta);
        
    }
    
    public void multiplicacion(int valor1, int valor2){
        int producto;
        producto = valor1 + valor2;
        System.out.printf("El producto de %d y %d \nEs igual a:\n\t%d\n",valor1, valor2, producto);
        
    }
    
    public void division(int valor1, int valor2){
        int cosiente;
        cosiente = valor1 + valor2;
        System.out.printf("El cosiente entre %d y %d \nEs igual a:\n\t%d\n",valor1, valor2, cosiente);
        
    }
    
    public void impresion(int valor1, int valor2, int opcion){
        
        if(opcion == 1){
            suma(valor1, valor2);
        }else{
            if(opcion == 2){
                resta(valor1, valor2);
            }else{
                if(opcion == 3){
                    multiplicacion(valor1, valor2);
                }else{
                    if(opcion == 4){
                        division(valor1, valor2);
                    }else{
                        System.out.println("esa opcion no existe");
                    }
                }
            }
        }            
    }
}
