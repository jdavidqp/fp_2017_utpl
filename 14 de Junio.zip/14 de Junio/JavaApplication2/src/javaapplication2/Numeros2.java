/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Administrador
 */
public class Numeros2 {
    
    public static void main(String[] args) {
        
        Presenta imprimir = new Presenta();
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese su nombre");
        String nombre = entrada.nextLine();
        
        System.out.println("Tipo de reporte 1  -  2");
        int tipo = entrada.nextInt();
        
        imprimir.impresion(tipo, nombre);
    }
}
