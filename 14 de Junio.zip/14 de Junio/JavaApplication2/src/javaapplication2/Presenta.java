/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Administrador
 */
public class Presenta {
    
    public void presentar_mayusculas(String valor ){
        
        System.out.printf("Nombre ingresado:\n\t%s\n", valor.toUpperCase());
    }
    public void presentar_minusculas(String valor ){
        
        System.out.printf("Nombre ingresado:\n\t%s\n", valor.toLowerCase());
    }
    public void impresion(int opcion, String valor2){
        
        if(opcion == 1){
            presentar_mayusculas(valor2);
        }else{
            if(opcion == 2){
                presentar_minusculas(valor2);
            }else{
                System.out.println("No hay reporte");
            }
        }
    }
}
