/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Administrador
 */
public class Principal {
    
    public static void main(String[] args) {
        
        Operacion op = new Operacion();
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese el primer valor");
        int num_1 = entrada.nextInt();
        
        System.out.println("Ingrese el segundo valor");
        int num_2 = entrada.nextInt();
        
        System.out.println("Ingrese una opcion deacuerdo a la operacion que desea realizar\n1 suma\n2 resta\n3 multiplicacion\n4 division");
        int opcion = entrada.nextInt();
        
        op.impresion(num_1, num_2, opcion);
        
    }
}
