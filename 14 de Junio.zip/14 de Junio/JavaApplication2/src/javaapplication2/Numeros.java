/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Administrador
 */
public class Numeros {
    
    public static void main(String[] args) {
        
        Presenta imprimir = new Presenta();
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese su nombre");
        String nombre = entrada.nextLine();
        
        System.out.println("Tipo de reporte 1  -  2");
        int tipo = entrada.nextInt();
        
        if(tipo == 1 ){
            imprimir.presentar_mayusculas(nombre);
            
        }else{
            if(tipo == 2){
                imprimir.presentar_minusculas(nombre);
            }else{
                System.out.println("No hay reporte");
            }
        }
    }
}
