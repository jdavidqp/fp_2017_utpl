/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author Administrador
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Estudiantes e1 = new Estudiantes();
        Estudiantes e2 = new Estudiantes();
        
        int suma_edades = 0;
        double promedio = 0;
        
        //e1.nombre = "maria";
        //e2.nombre = "luis";
        
        String valor_nombre = "Luis";
        e1.agregar_nombre(valor_nombre);
        e2.agregar_nombre("Maria");
        
        //e1.edad = 18;
        //e2.edad = 17;
        
        e1.agregar_edad(18);
        e2.agregar_edad(17);
        
        //suma_edades = e1.edad + e2.edad;
        suma_edades = e1.obtener_edad() + e2.obtener_edad();
        promedio = (double)suma_edades/2;
        
        
        System.out.println(promedio);
    }
    
}
