/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author Administrador
 */
public class Principal_Cuadrado {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        for(int i = 1; i<=4; i++){
            
            System.out.println("Ingrese el lado");
            int lado = entrada.nextInt();
            Cuadrado c = new Cuadrado();
            c.agregar_lado(lado);
            System.out.printf("Cuadrado con lado %d\n\tArea = %d\n\tPerimetro = %d\n", c.obtener_lado(), c.obtener_area(),c.obtener_perimetro());
        }
        
    }
}
