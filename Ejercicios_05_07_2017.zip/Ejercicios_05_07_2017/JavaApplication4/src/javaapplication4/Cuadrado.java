/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author Administrador
 */
public class Cuadrado {
    
    private int lado;
    
    
    public void agregar_lado(int e){
        lado = e;
    }
    
    public int obtener_lado(){ 
        return lado;  
    }
    
    public int obtener_area(){ 
        int area = obtener_lado() * obtener_lado();
        return area;  
    }

    public int obtener_perimetro(){ 
        int perimetro = obtener_lado() + obtener_lado() + obtener_lado() + obtener_lado();
        return perimetro;  
    }
    
}
