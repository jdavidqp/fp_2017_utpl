/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Administrador
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Estudiantes e1 = new Estudiantes();
        Estudiantes e2 = new Estudiantes();
        
        int suma_edades = 0;
        double promedio = 0;
        
        e1.nombre = "maria";
        e2.nombre = "luis";
       
        e1.edad = 18;
        e2.edad = 17;
        
        suma_edades = e1.edad + e2.edad;
        promedio = (double)suma_edades/2;
        
        System.out.println(promedio);
        
    }
    
}
